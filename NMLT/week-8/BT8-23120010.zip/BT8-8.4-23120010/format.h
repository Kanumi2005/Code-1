#ifndef FORMAT_H
#define FORMAT_H

void trim_left(char str[], int &i);
void one_space_and_trim_right(char str[], int &i);



#endif