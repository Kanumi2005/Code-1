#ifndef IO_84_H
#define IO_84_H

void input(char str[]);
void output(char str[]);

#endif