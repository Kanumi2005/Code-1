#include "io-84.h"


int main() {
    char str[100];
    input(str);
    output(str);

    return 0;
}