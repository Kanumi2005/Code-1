#ifndef IO_91_H
#define IO_91_H
#include "fraction.h"

void input(frac &obj);

void output(frac sum, frac product, frac reverse_1, frac reverse_2, frac shorten_1, frac shorten_2);

#endif