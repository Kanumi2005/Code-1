#include "date.h"
#include "io-94.h"

int main() {
    date arr[100];
    int n;

    input(arr, n);
    output(arr, n);

    return 0;
}