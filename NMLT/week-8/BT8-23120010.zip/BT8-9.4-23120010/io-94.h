#ifndef IO_94_H
#define IO_94_H
#include "date.h"
void input(date arr[], int &n);
void output(date arr[], int n);

#endif