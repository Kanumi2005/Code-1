#ifndef SWAP_H
#define SWAP_H
#include "date.h"
void swap(date &a, date &b);

#endif