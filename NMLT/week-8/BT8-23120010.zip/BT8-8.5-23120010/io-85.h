#ifndef IO_85_H
#define IO_85_H

void input(char str[], char &c);

void output(char word[][100], const int &size);

#endif