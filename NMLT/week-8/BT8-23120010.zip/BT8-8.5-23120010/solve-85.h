#ifndef SOLVE_85_H
#define SOLVE_85_H

void split(char str[], const char &c, char word[][100], int &size);

#endif