#include "plane.h"
#include "io-93.h"

int main() {
    triangle ABC;
    input(ABC);
    output(ABC);

    return 0;
}