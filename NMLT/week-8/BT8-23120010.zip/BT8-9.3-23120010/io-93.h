#ifndef IO_93_H
#define IO_93_H
#include "plane.h"

void input(triangle &ABC);
void output(triangle &ABC);

#endif