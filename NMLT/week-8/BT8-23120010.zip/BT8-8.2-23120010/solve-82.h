#ifndef SOLVE_82_H
#define SOLVE_82_H

void find(char dest[], char src[], int arr[], int &size);
void erase(char before[], char after[], int arr[], int size, int len);

#endif