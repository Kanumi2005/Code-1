#ifndef IO_82_H
#define IO_82_H

void input(char s[], char t[]);
void output(char str[]);

#endif