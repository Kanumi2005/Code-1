#ifndef CHECK_SUB_STR_H
#define CHECK_SUB_STR_H

bool is_sub_str(char dest[], char src[]);

#endif