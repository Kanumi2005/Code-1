#ifndef SORT_H
#define SORT_H
#include "student.h"

void sort(HocSinh hs[], int n);

#endif