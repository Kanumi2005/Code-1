#include "student.h"
#include "io-92.h"

int main() {
    HocSinh hs[100] {};
    int n;

    input(hs, n);
    output(hs, n);

    return 0;
}