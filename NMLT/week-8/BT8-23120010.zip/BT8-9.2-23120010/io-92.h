#ifndef IO_92_H
#define IO_92_H
#include "student.h"

void input(HocSinh hs[], int &n);

void output(HocSinh hs[], int n);

#endif