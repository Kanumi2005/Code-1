#ifndef SOLVE_83_h
#define SOLVE_83_H

void count_freq(char str[], char freq[][100]);

#endif