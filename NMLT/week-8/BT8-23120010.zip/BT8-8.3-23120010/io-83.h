#ifndef IO_83_H
#define IO_83_H

void input(char str[]);
void output(char freq[][100]);

#endif