#include "interface.h"

void interface() {
    std::cout << "1. Bai tap 6.1.\n"
              << "2. Bai tap 6.2.\n"
              << "3. Bai tap 6.3.\n"
              << "4. Bai tap 6.4.\n"
              << "5. Thoat.\n"
              << "Lua chon cua ban (1-5): ";
}