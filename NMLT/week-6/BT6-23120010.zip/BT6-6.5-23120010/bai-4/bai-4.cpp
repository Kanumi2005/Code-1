#include "bai-4.h"
#include "io-4.h"
#include "solve-4.h"
void bai_4() {
    int before, after, cost;

    input_4(before, after);
    solve_4(before, after, cost);
    output_4(cost);
}