#ifndef IO_4_H
#define IO_4_H

void input_4(int &before, int &after);

void output_4(int cost);
#endif