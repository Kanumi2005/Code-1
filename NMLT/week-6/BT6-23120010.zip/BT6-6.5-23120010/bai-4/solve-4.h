#ifndef SOLVE_4_H
#define SOLVE_4_H

void solve_4(int before, int after, int &cost);

#endif