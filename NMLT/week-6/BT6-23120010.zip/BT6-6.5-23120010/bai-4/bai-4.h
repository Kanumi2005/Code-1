#ifndef BAI_4_H
#define BAI_4_H

void bai_4();

#endif