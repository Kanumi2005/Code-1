#ifndef BAI_1_H
#define BAI_1_H

void bai_1();

#endif
