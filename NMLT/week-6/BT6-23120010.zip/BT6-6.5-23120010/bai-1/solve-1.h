#ifndef SOLVE_1_H
#define SOLVE_1_H

void solve_1(bool is_prime[], int n);

#endif