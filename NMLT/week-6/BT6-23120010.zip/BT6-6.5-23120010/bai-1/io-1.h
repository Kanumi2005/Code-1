#ifndef IO_1_H
#define IO_1_H

void input_1(int &n);
void output_1(bool arr[], int n);

#endif