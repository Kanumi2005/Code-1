#ifndef IMPLEMENTATION_H
#define IMPLEMENTATION_H

#include <iostream>
#include "./bai-1/bai-1.h"
#include "./bai-2/bai-2.h"
#include "./bai-3/bai-3.h"
#include "./bai-4/bai-4.h"

bool implement();

#endif