#ifndef BAI_3_H
#define BAI_3_H

void bai_3();

#endif