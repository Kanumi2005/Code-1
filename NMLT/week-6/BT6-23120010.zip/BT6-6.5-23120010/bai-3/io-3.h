#ifndef IO_3_H
#define IO_3_H

void input_3(double &a, double &b, double &c);

void output_3(bool is_triangle, bool is_right, bool is_isosceles, bool is_equilateral);

#endif