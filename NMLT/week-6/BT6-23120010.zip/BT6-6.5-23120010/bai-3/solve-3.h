#ifndef SOLVE_3_H
#define SOLVE_3_H

bool is_triangle(double a, double b, double c);
bool is_right(double a, double b, double c);
bool is_isosceles(double a, double b, double c);
bool is_equilateral(double a, double b, double c);

#endif