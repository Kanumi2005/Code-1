#ifndef SOLVE_2_H
#define SOLVE_2_H

void solve_2(int &a, int &b, int &c, int &d, char &operation);

#endif