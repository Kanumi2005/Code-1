#ifndef BAI_2_H
#define BAI_2_H

void bai_2();

#endif