#ifndef IO_2_H
#define IO_2_H

void input_2(int &a, int &b, int &c, int &d, char &operation);
void output_2(int &a, int &b);

#endif