#ifndef INTERFACE_H
#define INTERFACE_H
#include <iostream>

void interface();

#endif