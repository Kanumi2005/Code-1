#ifndef IO_H
#define IO_H

void input(int arr[][100], int &n);
void output(int sum_main_diagonal,int sum_anti_diagonal, int row_max_sum, bool is_magic_square);

#endif