#ifndef ROW_COL_SUM_H
#define ROW_COL_SUM_H

int sum_row(int arr[][100],int row, int n);
int sum_col(int arr[][100],int col, int n);
#endif