#ifndef SOLVE_H
#define SOLVE_H

int sum_main_diagonal(int arr[][100], int n);
int sum_anti_diagonal(int arr[][100], int n);
int row_max_sum(int arr[][100], int n);
bool is_magic_square(int arr[][100], int n);

#endif