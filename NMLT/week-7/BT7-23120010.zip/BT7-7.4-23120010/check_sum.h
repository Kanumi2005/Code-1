#ifndef CHECK_SUM_H
#define CHECK_SUM_H

bool is_sum(int arr[][100], int m, int n, int row, int col);

#endif