#ifndef COL_MAX_H
#define COL_MAX_H

int col_max(int arr[][100], int m, int col);


#endif