#ifndef IO_H
#define IO_H

void input(int arr[][100], int &m, int &n);
void output(int e[], int size);

#endif