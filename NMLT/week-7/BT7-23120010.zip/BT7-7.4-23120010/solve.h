#ifndef SOLVE_H
#define SOLVE_H

void find_elements(int arr[][100], int m, int n, int e[], int &size);

#endif