#ifndef SOLVE_H
#define SOLVE_H

void rotate_left(int arr[][100], int m, int n, int arr_left[][100], int &size_row, int &size_col);
void rotate_right(int arr[][100], int m, int n, int arr_right[][100], int &size_row, int &size_col);

#endif