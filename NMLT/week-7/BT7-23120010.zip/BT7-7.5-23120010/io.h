#ifndef IO_H
#define IO_H

void input(int arr[][100], int &m, int &n);
void output(int arr[][100], int size_row, int size_col);

#endif