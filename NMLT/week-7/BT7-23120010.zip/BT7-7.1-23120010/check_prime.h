#ifndef CHECK_PRIME_H
#define CHECK_PRIME_H

bool is_prime(int n);

#endif