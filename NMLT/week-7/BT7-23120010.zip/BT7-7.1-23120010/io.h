#ifndef IO_H
#define IO_H

void input(int arr[], int &n);
void output(int number_negative, int number_prime);

#endif