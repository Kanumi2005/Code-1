#ifndef SOLVE_H
#define SOLVE_H

int count_prime(int arr[], int n);
int count_negative(int arr[], int n);

#endif