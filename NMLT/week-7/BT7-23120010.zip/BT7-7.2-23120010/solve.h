#ifndef SOLVE_H
#define SOLVE_H

bool is_increasing(int arr[], int n);
bool is_symmetrical(int arr[], int n);
bool is_arithmetic(int arr[], int n);

#endif