#ifndef IO_H
#define IO_H

void input(int arr[], int &n);
void output(bool is_increasing, bool is_symmetrical, bool is_arithmetic);

#endif